import sys
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedShuffleSplit
from sklearn import preprocessing
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
from sklearn import model_selection
from sklearn import svm
from sklearn.model_selection import cross_val_predict
from sklearn.model_selection import GridSearchCV
from sklearn.svm import SVC
import pickle 
from rdkit import Chem
from rdkit.Chem import AllChem
from rdkit.Chem import SaltRemover
from pydpi.pydrug import PyDrug

p = str(sys.argv[1])
q = str(sys.argv[2])
#print p
#print q
a = open(""+p+"")
aa = a.read()
aaa = aa.split('\n')
#print len(aaa)
#fob = open(''+ q +'/result1.csv','a')
#fob.write('Name,Smile,Activity\n')
k = 0
#print 'helllllllllllllll'
while k<len(aaa):
#for ll in aaa:    
    data = pd.read_csv(r'C:\\Users\\Sachin\\Desktop\\Sahil\\239_refined_demetaled_wt.txt', sep='\t')
    #print (data.shape)
    #print (data.head())
    #print 'done',ll
    y = data.Activity.values
    #### Descriptors Values
    Location = r'C:\\Users\\Sachin\\Desktop\\Sahil\\239_cal_desc_pydpi.xlsx'
    df = pd.read_excel(Location)
    #print (df.head())
    X = np.asarray(df)
    #print (X.shape)
    #### Extracting External Dataset
    
    sss = StratifiedShuffleSplit(n_splits=5, test_size=0.2, random_state=0)
    for train_index, test_index in sss.split(X, y):
        X_tr, X_xt = X[train_index], X[test_index]
        y_tr, y_xt = y[train_index], y[test_index]
    #print (X_tr.shape, X_xt.shape)
    #### Normalization
    #data scaling range b/w 0-1
    min_max_scaler = preprocessing.MinMaxScaler()
    X_tr1 = min_max_scaler.fit_transform(X_tr)
    X_xt1 = min_max_scaler.transform(X_xt)
    #print (X_tr1.shape, X_xt1.shape)
    #### Recursive Feature Elimination

    model = LogisticRegression()
    rfe = RFE(model, 10)
    X_rfe = rfe.fit(X_tr1, y_tr)
    X_tr_rfe = rfe.transform(X_tr1)
    X_xt_rfe = rfe.transform(X_xt1)
    #print (X_tr_rfe.shape, X_xt_rfe.shape)

    features = np.array(list(df))
    selected_features = features[rfe.get_support()]
    #print (selected_features)
    #### Model
    
    def calc_performance(y_true, y_pred, labels=[1, 0]):
        TP=0
        FN=0
        FP=0
        TN=0
        for i in range(len(y_true)):
            if (y_true[i] == labels[0] and y_pred[i] == labels[0]): TP += 1.0
            if (y_true[i] == labels[0] and y_pred[i] == labels[1]): FN += 1.0
            if (y_true[i] == labels[1] and y_pred[i] == labels[0]): FP += 1.0
            if (y_true[i] == labels[1] and y_pred[i] == labels[1]): TN += 1.0  

        recall = TP/(TP+FN)
        specificity = TN/(TN+FP)
        try: precision = TP/(TP+FP)
        except: precision = 0
        accuracy = (TP+TN)/(TP+FP+TN+FN)
        balanced_acc = (recall+specificity)/2.0
        try: f1_score = 2*(recall*precision)/(recall+precision)
        except: f1_score = 0
        try: mcc = (TP*TN-FP*FN)/((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN))**0.5
        except: mcc = 0
        return [round(balanced_acc,4), round(recall,4), round(specificity,4), 
                round(precision,4), round(accuracy,4), round(f1_score,4), round(mcc,4), 
                int(sum(y_true)), int(len(y_true)-sum(y_true))]

    skf = model_selection.StratifiedKFold(n_splits=5, shuffle=True, random_state=0)

    #### SVM

    '''temp = []
    clf = svm.SVC()

    clf.fit(X_tr_rfe, y_tr)

    y_pred= clf.predict(X_tr_rfe)
    temp.append(['Train']+calc_performance(y_tr, y_pred))

    y_pred = cross_val_predict(clf, X_tr_rfe, y_tr, cv=skf, n_jobs=1)
    temp.append(['5 fold CV']+calc_performance(y_tr, y_pred))

    y_pred = clf.predict(X_xt_rfe)
    temp.append(['External Validation']+calc_performance(y_xt, y_pred))

    result = pd.DataFrame(temp, columns=['dataset','BCR', 'Recall', 'Specificity', 'Precision', 
                                       'Accuracy', 'f1_score', 'MCC', '1s', '0s'])
    #print (result)'''


    # ### Grid Search
    '''temp1 = []
    clf = svm.SVC()

    param_grid = [{'kernel': ['rbf'], 'gamma': [1e-1, 1e-2, 1e-3, 1e-4],
                         'C': [1, 10, 100, 1000]}]
    grid_search = GridSearchCV(clf, param_grid, n_jobs=1, cv=skf)
    grid_search.fit(X_tr_rfe, y_tr)
    rzlt1 = [grid_search.best_params_['C'],grid_search.best_params_['gamma']]
    temp1.append(rzlt1)
    #print (rzlt1)'''


    '''temp2 = []
    clf1 = svm.SVC(C=10.0, cache_size=500, gamma=0.1, kernel='rbf')

    clf1.fit(X_tr_rfe, y_tr)

    y_pred= clf1.predict(X_tr_rfe)
    temp2.append(['Train']+calc_performance(y_tr, y_pred))

    y_pred = cross_val_predict(clf1, X_tr_rfe, y_tr, cv=skf, n_jobs=1)
    temp2.append(['5 fold CV']+calc_performance(y_tr, y_pred))

    y_pred = clf1.predict(X_xt_rfe)
    temp2.append(['External Validation']+calc_performance(y_xt, y_pred))

    result1 = pd.DataFrame(temp2, columns=['dataset','BCR', 'Recall', 'Specificity', 'Precision', 
                                       'Accuracy', 'f1_score', 'MCC', '1s', '0s'])
    #print (result1)'''



    temp3 = []
    clf2 = svm.SVC(C=10.0, cache_size=500, gamma=0.15, kernel='rbf')

    clf2.fit(X_tr_rfe, y_tr)

    y_pred= clf2.predict(X_tr_rfe)
    temp3.append(['Train']+calc_performance(y_tr, y_pred))

    y_pred = cross_val_predict(clf2, X_tr_rfe, y_tr, cv=skf, n_jobs=1)
    temp3.append(['5 fold CV']+calc_performance(y_tr, y_pred))

    y_pred = clf2.predict(X_xt_rfe)
    temp3.append(['External Validation']+calc_performance(y_xt, y_pred))

    result3 = pd.DataFrame(temp3, columns=['dataset','BCR', 'Recall', 'Specificity', 'Precision', 
                                       'Accuracy', 'f1_score', 'MCC', '1s', '0s'])
    #print (result3)

    

    # ### save model



    Selected_model = pickle.dumps(clf2)

     
    #after model was saved we have to make the prediction of the new data on the saved model in clf in pickle


    #b= [x for x in raw_input("Kindly input the Name of the molecule and SMILE notation respectively, separated by a comma(','):").split(',')]
    #print b
    b = (aaa[k]).split(',')

    data1 = pd.DataFrame(data=[b], columns=["Name", "SMILES"])
    #print 'completd...........ghgh'
    data1.head()
    data1
    
    remover = SaltRemover.SaltRemover()

    new_smiles = []
    for i in data1.SMILES.values:
        m = Chem.MolFromSmiles(i)
        if m:
            m1 = remover.StripMol(m)
            new_smiles.append(Chem.MolToSmiles(m1))
        else:
            print (i)
    #print (len(new_smiles))

    data1['CANONICAL_SMILES'] = new_smiles
    
    
    #Descriptors Calculation
    
    drug = PyDrug()
    desc = []
    for s in data1.CANONICAL_SMILES.values:
		drug.ReadMolFromSmile(s)
        alld = drug.GetAllDescriptor()
        des = alld.values()
        desc.append(des)
	
    temp4 = pd.DataFrame(desc,columns=alld.keys())
	temp =  (GetFpArray(temp4))
    np.savetxt('C:\\Users\\Sachin\\Desktop\\Sahil\\descriptors.csv',temp,delimiter=',')
	df1 = pd.read_csv('C:\\Users\\Sachin\\Desktop\\Sahil\\descriptors.csv', sep=',', names=(alld.keys())
    df1.head()
    #print (temp4)
	
    # normalization of the calculated descriptors of new data 

    min_max_scaler = preprocessing.MinMaxScaler()
    X_tr1 = min_max_scaler.fit_transform(X_tr) #train data 
    X_pred = min_max_scaler.transform(df1) #new predictive data
    #print (X_tr1.shape, X_pred.shape)


    # feature selection of the calculated descriptors of new data 

    model = LogisticRegression()
    rfe = RFE(model, 10)
    X_rfe = rfe.fit(X_tr1, y_tr)
    X_tr_rfe = rfe.transform(X_tr1)
    X_pred_rfe = rfe.transform(X_pred)
    #print (X_tr_rfe.shape, X_pred_rfe.shape)



    #make the predcition of new data with save model 
     
    prediction = pickle.loads(Selected_model)
    res = prediction.predict(X_pred_rfe)
    print res[0]
    #print 'Done'
    #print aaa[k]
    k+=1
#fob.close()
a.close()
print 'done'
